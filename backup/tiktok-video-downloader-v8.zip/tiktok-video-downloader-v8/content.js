(() => {
  if (globalThis.__TT_VIDEO_DOWNLOADER_V8__) return;
  globalThis.__TT_VIDEO_DOWNLOADER_V8__ = true;

  const activeBlobs = new Set();
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  const REQUEST_INIT = {
    method: "GET",
    mode: "cors",
    cache: "no-cache",
    credentials: "include",
    redirect: "follow"
  };

  function decodeUrl(value) {
    if (!value || typeof value !== "string") return null;
    try {
      if (/^https?:/i.test(value)) return value.replace(/&amp;/g, "&");
      return JSON.parse(`"${value.replace(/"/g, '\\"')}"`);
    } catch {
      return value
        .replace(/\\u002F/gi, "/")
        .replace(/\\u0026/gi, "&")
        .replace(/\\u003D/gi, "=")
        .replace(/\\u003F/gi, "?")
        .replace(/\\\//g, "/")
        .replace(/&amp;/g, "&");
    }
  }

  function sanitize(value, fallback = "video") {
    return String(value || fallback)
      .replace(/[<>:"/\\|?*\x00-\x1F]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 100) || fallback;
  }

  function videoIdFromUrl(url) {
    return String(url || "").match(/\/video\/(\d+)/i)?.[1] || null;
  }

  function authorFromUrl(url) {
    return String(url || "").match(/\/@([^/]+)\/video\//i)?.[1] || null;
  }

  function isLikelyVideoUrl(raw) {
    if (!raw || typeof raw !== "string") return false;
    const decoded = decodeUrl(raw);
    if (!decoded || !/^https?:\/\//i.test(decoded)) return false;
    const lower = decoded.toLowerCase();
    if (/\.(?:js|css|json|jpg|jpeg|png|webp|avif|gif|svg|woff2?)(?:\?|$)/i.test(lower)) return false;

    let host = "";
    try { host = new URL(decoded).hostname.toLowerCase(); } catch {}
    const hostOk = /(tiktokcdn|tiktokv|ibytedtos|tiktok\.com)/i.test(host || lower);
    if (!hostOk) return false;

    return lower.includes("mime_type=video")
      || lower.includes("video_mp4")
      || lower.includes("bytevc")
      || lower.includes("hev1")
      || lower.includes("hvc1")
      || lower.includes("/video/tos/")
      || lower.includes(".mp4")
      || lower.includes(".webm");
  }

  function uniqueVideoUrls(values) {
    const out = [];
    const seen = new Set();
    for (const value of values.flat(Infinity)) {
      const url = decodeUrl(value);
      if (!isLikelyVideoUrl(url) || seen.has(url)) continue;
      seen.add(url);
      out.push(url);
    }
    return out;
  }

  function urlsFromValue(value) {
    if (!value) return [];
    if (typeof value === "string") return [value];
    if (Array.isArray(value)) return value.flatMap(urlsFromValue);
    if (typeof value !== "object") return [];

    const out = [];
    for (const key of ["urlList", "UrlList", "url_list", "urls"]) {
      if (value[key]) out.push(...urlsFromValue(value[key]));
    }
    for (const key of ["url", "Url", "src"]) {
      if (typeof value[key] === "string") out.push(value[key]);
    }
    return out;
  }

  function extractCandidatesFromItem(item) {
    if (!item || typeof item !== "object") return [];
    const video = item.video && typeof item.video === "object" ? item.video : item;
    const candidates = [];

    for (const key of [
      "downloadAddr",
      "playAddr",
      "playAddrH264",
      "playAddrBytevc1",
      "playApi",
      "play_url",
      "download_url"
    ]) {
      candidates.push(...urlsFromValue(video[key]));
    }

    const bitrateInfo = video.bitrateInfo || video.bitrate_info || [];
    if (Array.isArray(bitrateInfo)) {
      const sorted = [...bitrateInfo].sort((a, b) => Number(b?.Bitrate || b?.bitrate || 0) - Number(a?.Bitrate || a?.bitrate || 0));
      for (const entry of sorted) {
        candidates.push(...urlsFromValue(entry?.PlayAddr));
        candidates.push(...urlsFromValue(entry?.playAddr));
        candidates.push(...urlsFromValue(entry?.play_addr));
      }
    }

    return uniqueVideoUrls(candidates);
  }

  async function getItemDetail(videoId) {
    if (!videoId) throw new Error("El video no tiene ID.");
    const url = `https://www.tiktok.com/api/item/detail/?aid=1988&itemId=${encodeURIComponent(videoId)}`;
    const response = await fetch(url, REQUEST_INIT);
    if (!response.ok) throw new Error(`API TikTok HTTP ${response.status}`);

    const raw = await response.text();
    const cleaned = raw.trim()
      .replace(/^for\s*\(;;\);\s*/i, "")
      .replace(/^\)\]\}',?\s*/, "");

    let data;
    try { data = JSON.parse(cleaned); }
    catch { throw new Error("La API no devolvió JSON de video."); }

    const item = data?.itemInfo?.itemStruct || data?.itemInfo?.item_struct || null;
    if (!item) throw new Error("La API no devolvió itemStruct.");
    if (String(item.id || item.itemId || "") !== String(videoId)) {
      throw new Error("La API devolvió otro video.");
    }
    return item;
  }

  function findExactVideoObject(root, expectedId) {
    if (!root || !expectedId) return null;
    const seen = new WeakSet();
    let exact = null;

    const walk = (value, depth = 0) => {
      if (exact || !value || depth > 22 || typeof value !== "object" || seen.has(value)) return;
      seen.add(value);

      const id = String(value.id || value.itemId || value.aweme_id || "");
      if (id === String(expectedId) && value.video && typeof value.video === "object") {
        exact = value;
        return;
      }

      if (Array.isArray(value)) {
        for (const child of value) walk(child, depth + 1);
      } else {
        for (const child of Object.values(value)) walk(child, depth + 1);
      }
    };

    walk(root);
    return exact;
  }

  function exactItemFromDocument(doc, expectedId) {
    const ids = ["__UNIVERSAL_DATA_FOR_REHYDRATION__", "SIGI_STATE", "__NEXT_DATA__"];
    for (const id of ids) {
      const script = doc.getElementById?.(id);
      if (!script?.textContent) continue;
      try {
        const root = JSON.parse(script.textContent);
        const exact = findExactVideoObject(root, expectedId);
        if (exact) return exact;
      } catch {}
    }
    return null;
  }

  function exactItemFromHtml(html, expectedId) {
    const ids = ["__UNIVERSAL_DATA_FOR_REHYDRATION__", "SIGI_STATE", "__NEXT_DATA__"];
    for (const id of ids) {
      const escaped = id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const re = new RegExp(`<script[^>]+id=["']${escaped}["'][^>]*>([\\s\\S]*?)<\\/script>`, "i");
      const match = html.match(re);
      if (!match?.[1]) continue;
      try {
        const root = JSON.parse(match[1]);
        const exact = findExactVideoObject(root, expectedId);
        if (exact) return exact;
      } catch {}
    }
    return null;
  }

  function regexCandidatesFromHtml(html) {
    const out = [];
    for (const key of ["downloadAddr", "playAddr", "playAddrH264", "playAddrBytevc1"]) {
      const re = new RegExp(`"${key}"\\s*:\\s*"([^"]+)"`, "gi");
      let match;
      while ((match = re.exec(html)) && out.length < 60) out.push(match[1]);
    }
    return uniqueVideoUrls(out);
  }

  async function pageCandidates(item, strict = true) {
    const expectedId = String(item?.id || videoIdFromUrl(item?.pageUrl) || "");
    if (!expectedId) return [];

    const candidates = [];

    const docExact = exactItemFromDocument(document, expectedId);
    if (docExact) candidates.push(...extractCandidatesFromItem(docExact));

    const url = item?.pageUrl || location.href;
    try {
      const response = await fetch(url, REQUEST_INIT);
      if (response.ok) {
        const html = await response.text();
        const htmlExact = exactItemFromHtml(html, expectedId);
        if (htmlExact) candidates.push(...extractCandidatesFromItem(htmlExact));
        if (!strict && videoIdFromUrl(url) === expectedId) {
          candidates.push(...regexCandidatesFromHtml(html));
        }
      }
    } catch {}

    return uniqueVideoUrls(candidates);
  }

  function currentResourceCandidates() {
    const values = [];
    const entries = performance.getEntriesByType("resource");
    for (let i = entries.length - 1; i >= 0; i -= 1) {
      const name = entries[i]?.name;
      if (isLikelyVideoUrl(name)) values.push(name);
      if (values.length >= 30) break;
    }

    for (const video of document.querySelectorAll("video")) {
      if (isLikelyVideoUrl(video.currentSrc)) values.unshift(video.currentSrc);
      if (isLikelyVideoUrl(video.src)) values.unshift(video.src);
      for (const source of video.querySelectorAll("source")) {
        if (isLikelyVideoUrl(source.src)) values.unshift(source.src);
      }
    }
    return uniqueVideoUrls(values);
  }

  function isMp4Header(buffer) {
    const b = new Uint8Array(buffer);
    return b.length >= 12 && String.fromCharCode(b[4], b[5], b[6], b[7]) === "ftyp";
  }

  function isWebmHeader(buffer) {
    const b = new Uint8Array(buffer);
    return b.length >= 4 && b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3;
  }

  async function fingerprintBlob(blob) {
    const part = 128 * 1024;
    const head = new Uint8Array(await blob.slice(0, Math.min(part, blob.size)).arrayBuffer());
    const tailStart = Math.max(0, blob.size - part);
    const tail = new Uint8Array(await blob.slice(tailStart, blob.size).arrayBuffer());
    const sizeBytes = new TextEncoder().encode(String(blob.size));
    const combined = new Uint8Array(head.length + tail.length + sizeBytes.length);
    combined.set(head, 0);
    combined.set(tail, head.length);
    combined.set(sizeBytes, head.length + tail.length);
    const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", combined));
    return Array.from(digest).map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  async function fetchRealVideo(url) {
    let response;
    try {
      response = await fetch(url, REQUEST_INIT);
    } catch (error) {
      return { ok: false, error: `Fetch bloqueado: ${error?.message || error}` };
    }

    if (!response.ok) return { ok: false, error: `HTTP ${response.status}` };

    const type = (response.headers.get("content-type") || "").toLowerCase();
    const blob = await response.blob();
    if (blob.size < 1000) return { ok: false, error: `Respuesta demasiado pequeña (${blob.size} bytes)` };

    const head = await blob.slice(0, 32).arrayBuffer();
    const mp4 = isMp4Header(head);
    const webm = isWebmHeader(head);
    const videoType = type.startsWith("video/") || type.includes("application/octet-stream");

    if (!mp4 && !webm && !videoType) {
      return { ok: false, error: `No es video (${type || "sin content-type"})` };
    }

    const mime = mp4 ? "video/mp4" : (webm ? "video/webm" : (type.split(";")[0] || "video/mp4"));
    const normalized = blob.type === mime ? blob : new Blob([blob], { type: mime });
    const fingerprint = await fingerprintBlob(normalized);
    const blobUrl = URL.createObjectURL(normalized);
    activeBlobs.add(blobUrl);
    return { ok: true, blobUrl, mime, size: normalized.size, fingerprint };
  }

  async function resolveExactVideo(item, strict) {
    const expectedId = String(item?.id || videoIdFromUrl(item?.pageUrl) || "");
    if (!expectedId) throw new Error("El video no tiene ID.");

    const pageId = videoIdFromUrl(location.href);
    if (pageId && pageId !== expectedId) {
      throw new Error(`La pestaña abrió otro video (${pageId}).`);
    }

    const errors = [];
    const candidates = [];

    try {
      const apiItem = await getItemDetail(expectedId);
      candidates.push(...extractCandidatesFromItem(apiItem));
      item = {
        ...item,
        title: item.title || apiItem.desc || apiItem.description || null,
        author: item.author || apiItem.author?.uniqueId || apiItem.author?.unique_id || null
      };
    } catch (error) {
      errors.push(`API: ${error?.message || error}`);
    }

    candidates.push(...await pageCandidates(item, strict));

    if (Array.isArray(item?.mediaCandidates)) candidates.push(...item.mediaCandidates);
    if (item?.mediaUrl) candidates.push(item.mediaUrl);

    if (!strict) {
      await sleep(900);
      candidates.push(...currentResourceCandidates());
    }

    const unique = uniqueVideoUrls(candidates).slice(0, 40);
    if (!unique.length) throw new Error(errors[0] || "No encontré URL de video para este ID.");

    for (const url of unique) {
      const result = await fetchRealVideo(url);
      if (result.ok) return { item, ...result, sourceUrl: url };
      errors.push(result.error);
    }

    throw new Error(errors.slice(-5).join(" | ") || "TikTok no entregó un video válido.");
  }

  function makeFilename(item, index, mime) {
    const author = sanitize(item.author || authorFromUrl(item.pageUrl) || "TikTok", "TikTok");
    const title = sanitize(item.title || `video-${item.id || index + 1}`, `video-${index + 1}`);
    const id = item.id ? ` [${sanitize(item.id)}]` : "";
    const ext = /webm/i.test(mime) ? "webm" : "mp4";
    return `TikTok/${String(index + 1).padStart(3, "0")} - ${author} - ${title}${id}.${ext}`;
  }

  function addOrMerge(map, item) {
    if (!item) return;
    const key = item.id || item.pageUrl;
    if (!key) return;
    const existing = map.get(key) || {};
    map.set(key, Object.fromEntries(
      Object.entries({ ...existing, ...item }).filter(([, value]) => value != null && value !== "")
    ));
  }

  function collectFromDom(map) {
    for (const anchor of document.querySelectorAll('a[href*="/video/"]')) {
      const href = anchor.href || anchor.getAttribute("href") || "";
      const id = videoIdFromUrl(href);
      if (!id) continue;

      const card = anchor.closest('[data-e2e="user-post-item"], div[class*="DivItemContainer"], div[class*="DivVideoFeed"]') || anchor;
      const img = card.querySelector?.("img") || anchor.querySelector?.("img");
      addOrMerge(map, {
        id,
        pageUrl: href,
        author: authorFromUrl(href),
        title: img?.alt || anchor.getAttribute("aria-label") || null,
        cover: img?.src || img?.currentSrc || null
      });
    }
  }

  function maybeVideoObject(obj) {
    if (!obj || typeof obj !== "object") return null;
    const id = obj.id || obj.itemId || obj.aweme_id || null;
    if (!id || !obj.video || typeof obj.video !== "object") return null;

    const authorObj = obj.author || obj.authorInfo || {};
    const author = typeof authorObj === "string"
      ? authorObj
      : (authorObj.uniqueId || authorObj.unique_id || authorObj.nickname || null);

    const mediaCandidates = extractCandidatesFromItem(obj);
    const pageUrl = author ? `https://www.tiktok.com/@${String(author).replace(/^@/, "")}/video/${id}` : null;

    return {
      id: String(id),
      pageUrl,
      mediaUrl: mediaCandidates[0] || null,
      mediaCandidates,
      title: obj.desc || obj.description || obj.title || null,
      author,
      cover: obj.video.cover || obj.video.dynamicCover || obj.video.originCover || null
    };
  }

  function walkJson(value, map, seen, depth = 0) {
    if (!value || depth > 18 || typeof value !== "object" || seen.has(value)) return;
    seen.add(value);

    const item = maybeVideoObject(value);
    if (item) addOrMerge(map, item);

    if (Array.isArray(value)) {
      for (const child of value) walkJson(child, map, seen, depth + 1);
    } else {
      for (const child of Object.values(value)) walkJson(child, map, seen, depth + 1);
    }
  }

  function collectFromScripts(map) {
    const scripts = [
      document.getElementById("__UNIVERSAL_DATA_FOR_REHYDRATION__"),
      document.getElementById("SIGI_STATE"),
      document.getElementById("__NEXT_DATA__")
    ].filter(Boolean);

    for (const script of scripts) {
      const text = script.textContent || "";
      if (!text) continue;
      try { walkJson(JSON.parse(text), map, new WeakSet()); } catch {}
    }
  }

  function collectCurrentPage(map) {
    collectFromDom(map);
    collectFromScripts(map);
  }

  async function scanAllLoadedVideos({ autoScroll = true, maxItems = 400 } = {}) {
    const map = new Map();
    const initialY = window.scrollY;
    let stableRounds = 0;
    let lastCount = 0;
    let lastHeight = 0;

    collectCurrentPage(map);
    if (!autoScroll) return Array.from(map.values()).slice(0, maxItems);

    for (let i = 0; i < 80 && map.size < maxItems; i += 1) {
      collectCurrentPage(map);
      const count = map.size;
      const height = Math.max(document.body?.scrollHeight || 0, document.documentElement?.scrollHeight || 0);
      const atBottom = window.scrollY + window.innerHeight >= height - 24;

      if (count === lastCount && height === lastHeight && atBottom) stableRounds += 1;
      else stableRounds = 0;
      if (stableRounds >= 4) break;

      lastCount = count;
      lastHeight = height;
      window.scrollTo({ top: height, behavior: "instant" });
      await sleep(650);
    }

    collectCurrentPage(map);
    window.scrollTo({ top: initialY, behavior: "instant" });
    return Array.from(map.values()).slice(0, maxItems);
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "PING_TT_DOWNLOADER") {
      sendResponse({ ok: true, version: 8 });
      return;
    }

    if (message?.type === "SCAN_TIKTOK_VIDEOS") {
      (async () => {
        try {
          const videos = await scanAllLoadedVideos({
            autoScroll: message.autoScroll !== false,
            maxItems: Number(message.maxItems) || 400
          });
          sendResponse({ ok: true, videos, pageUrl: location.href });
        } catch (error) {
          sendResponse({ ok: false, error: error?.message || "No se pudo escanear TikTok." });
        }
      })();
      return true;
    }

    if (message?.type === "PREPARE_TIKTOK_WORKER") {
      (async () => {
        try {
          const item = message.item || {};
          const expectedId = String(item.id || videoIdFromUrl(item.pageUrl) || "");
          const currentId = videoIdFromUrl(location.href);
          if (expectedId && currentId !== expectedId) {
            throw new Error(`ID incorrecto en pestaña: esperaba ${expectedId}, abrió ${currentId || "ninguno"}.`);
          }

          const resolved = await resolveExactVideo(item, message.strict !== false);
          sendResponse({
            ok: true,
            blobUrl: resolved.blobUrl,
            filename: makeFilename(resolved.item, Number(item.__index) || 0, resolved.mime),
            bytes: resolved.size,
            mime: resolved.mime,
            fingerprint: resolved.fingerprint,
            id: expectedId
          });
        } catch (error) {
          sendResponse({ ok: false, error: error?.message || "No se pudo preparar el video." });
        }
      })();
      return true;
    }

    if (message?.type === "REVOKE_VIDEO_BLOB") {
      const url = message.blobUrl;
      if (url && activeBlobs.has(url)) {
        try { URL.revokeObjectURL(url); } catch {}
        activeBlobs.delete(url);
      }
      sendResponse?.({ ok: true });
      return;
    }
  });
})();
