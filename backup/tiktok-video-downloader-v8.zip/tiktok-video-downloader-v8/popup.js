const statusEl = document.getElementById("status");
const listEl = document.getElementById("list");
const counterEl = document.getElementById("counter");
const selectAllEl = document.getElementById("selectAll");
const scanBtn = document.getElementById("scan");
const downloadSelectedBtn = document.getElementById("downloadSelected");
const downloadAllBtn = document.getElementById("downloadAll");
const batchPanel = document.getElementById("batchPanel");
const batchText = document.getElementById("batchText");
const batchPercent = document.getElementById("batchPercent");
const batchBar = document.getElementById("batchBar");

let videos = [];
let selected = new Set();
let busy = false;
let batchRunning = false;
let activeTabId = null;

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function keyFor(video, index) {
  return video.id || video.pageUrl || String(index);
}

function updateControls() {
  const count = videos.length;
  const selectedCount = selected.size;
  counterEl.textContent = `${count} video${count === 1 ? "" : "s"} · ${selectedCount} seleccionado${selectedCount === 1 ? "" : "s"}`;
  selectAllEl.checked = count > 0 && selectedCount === count;
  selectAllEl.indeterminate = selectedCount > 0 && selectedCount < count;
  downloadSelectedBtn.disabled = busy || batchRunning || selectedCount === 0;
  downloadAllBtn.disabled = busy || batchRunning || count === 0;
  downloadAllBtn.textContent = count ? `DESCARGAR TODOS (${count})` : "DESCARGAR TODOS";
  scanBtn.disabled = busy || batchRunning;
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "PING_TT_DOWNLOADER" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
}

function render() {
  if (!videos.length) {
    listEl.innerHTML = '<div class="empty">No encontré videos cargados en esta página de TikTok.</div>';
    updateControls();
    return;
  }

  listEl.innerHTML = videos.map((video, index) => {
    const key = keyFor(video, index);
    const thumb = video.cover
      ? `<img class="thumb" src="${escapeHtml(video.cover)}" alt="">`
      : '<div class="thumb placeholder">VIDEO</div>';
    return `
      <article class="item" data-index="${index}">
        <input class="row-check" type="checkbox" data-key="${escapeHtml(key)}" ${selected.has(key) ? "checked" : ""}>
        ${thumb}
        <div class="info">
          <div class="title">${escapeHtml(video.title || "TikTok video")}</div>
          <div class="author">@${escapeHtml(video.author || "TikTok")}</div>
          <div class="id">${escapeHtml(video.id || "sin ID")}</div>
        </div>
        <button class="mini one" data-index="${index}" title="Descargar este video">↓</button>
      </article>`;
  }).join("");

  for (const checkbox of listEl.querySelectorAll(".row-check")) {
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) selected.add(checkbox.dataset.key);
      else selected.delete(checkbox.dataset.key);
      updateControls();
    });
  }

  for (const btn of listEl.querySelectorAll(".one")) {
    btn.addEventListener("click", async () => {
      const index = Number(btn.dataset.index);
      const item = videos[index];
      if (!item || batchRunning) return;
      await startBatch([item], index);
    });
  }

  updateControls();
}

async function scan() {
  if (batchRunning) return;
  busy = true;
  videos = [];
  selected.clear();
  listEl.innerHTML = '<div class="empty">Escaneando TikTok y cargando los videos del perfil…</div>';
  statusEl.textContent = "Escaneando la página…";
  updateControls();

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTabId = tab?.id || null;
  if (!tab?.id || !tab.url?.includes("tiktok.com")) {
    statusEl.textContent = "La pestaña activa no es TikTok.";
    busy = false;
    render();
    return;
  }

  try {
    await ensureContentScript(tab.id);
    const response = await chrome.tabs.sendMessage(tab.id, {
      type: "SCAN_TIKTOK_VIDEOS",
      autoScroll: true,
      maxItems: 400
    });

    if (!response?.ok) throw new Error(response?.error || "No se pudo escanear TikTok.");

    const dedupe = new Map();
    for (const video of response.videos || []) {
      const key = video.id || video.pageUrl;
      if (!key) continue;
      const existing = dedupe.get(key) || {};
      dedupe.set(key, Object.fromEntries(
        Object.entries({ ...existing, ...video }).filter(([, value]) => value != null && value !== "")
      ));
    }

    videos = Array.from(dedupe.values());
    videos.forEach((video, index) => selected.add(keyFor(video, index)));
    statusEl.textContent = videos.length ? `${videos.length} videos encontrados.` : "No encontré videos.";
  } catch (error) {
    statusEl.textContent = `No pude leer TikTok: ${error?.message || "error desconocido"}`;
  }

  busy = false;
  render();
}

async function startBatch(items, baseIndex = 0) {
  if (!items.length || batchRunning) return;

  const payload = items.map((item, i) => ({ ...item, __index: baseIndex + i }));
  const response = await chrome.runtime.sendMessage({
    type: "START_BATCH_DOWNLOAD",
    items: payload
  });

  if (!response?.ok) {
    statusEl.textContent = `Error: ${response?.error || "no se pudo iniciar la descarga"}`;
    return;
  }

  batchRunning = true;
  statusEl.textContent = `Descarga automática iniciada: ${items.length} video${items.length === 1 ? "" : "s"}.`;
  updateControls();
  await syncBatchState();
}

async function syncBatchState() {
  const { tiktokBatchState: state } = await chrome.storage.local.get("tiktokBatchState");
  if (!state) return;

  batchRunning = state.status === "running";
  const total = Number(state.total || 0);
  const completed = Number(state.completed || 0);
  const success = Number(state.success || 0);
  const failed = Number(state.failed || 0);
  const percent = total ? Math.min(100, Math.round((completed / total) * 100)) : 0;

  batchPanel.classList.toggle("hidden", !total);
  batchText.textContent = batchRunning
    ? `${completed}/${total} procesados · ${success} descargados${failed ? ` · ${failed} fallaron` : ""}`
    : `Finalizado · ${success}/${total} descargados${failed ? ` · ${failed} fallaron` : ""}`;
  batchPercent.textContent = `${percent}%`;
  batchBar.style.width = `${percent}%`;

  if (batchRunning) statusEl.textContent = "Descargando automáticamente. No necesitas ir uno por uno.";
  else if (total) statusEl.textContent = failed
    ? `Proceso terminado: ${success} descargados · ${failed} fallaron.`
    : `Proceso terminado: ${success} videos descargados.`;

  updateControls();
}

selectAllEl.addEventListener("change", () => {
  selected.clear();
  if (selectAllEl.checked) videos.forEach((video, index) => selected.add(keyFor(video, index)));
  render();
});

scanBtn.addEventListener("click", scan);
downloadSelectedBtn.addEventListener("click", () => {
  const items = videos.filter((video, index) => selected.has(keyFor(video, index)));
  startBatch(items, 0);
});
downloadAllBtn.addEventListener("click", () => startBatch(videos, 0));

setInterval(syncBatchState, 600);
syncBatchState();
scan();
