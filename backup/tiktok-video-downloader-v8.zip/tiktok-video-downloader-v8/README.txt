TikTok Video Downloader v8

Cambios principales:
- Botón DESCARGAR TODOS visible en la parte superior.
- Descarga automática por lotes; no hay que pulsar cada video.
- Cada video se abre en una pestaña de trabajo propia para resolver su MP4 por ID.
- Hasta 5 descargas simultáneas.
- Verificación de huella del archivo para evitar guardar el mismo video repetido con nombres diferentes.
- Las pestañas de trabajo se cierran automáticamente al terminar cada descarga.

Instalación:
1. Descomprime esta carpeta.
2. Abre chrome://extensions
3. Activa Modo desarrollador.
4. Pulsa "Cargar descomprimida".
5. Selecciona la carpeta tiktok-video-downloader-v8.
6. Abre el perfil de TikTok, abre la extensión y pulsa DESCARGAR TODOS.
