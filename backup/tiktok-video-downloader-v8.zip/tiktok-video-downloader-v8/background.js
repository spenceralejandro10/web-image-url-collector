const sessions = new Map();
const downloadWaiters = new Map();
let runningBatch = null;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function downloadFile(url, filename) {
  return new Promise((resolve) => {
    chrome.downloads.download({
      url,
      filename,
      saveAs: false,
      conflictAction: "uniquify"
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve({ ok: true, downloadId });
    });
  });
}

function waitForTabComplete(tabId, timeoutMs = 25000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timeout = setTimeout(() => finish(new Error("Tiempo agotado cargando el video.")), timeoutMs);

    const listener = (updatedId, changeInfo) => {
      if (updatedId === tabId && changeInfo.status === "complete") finish();
    };

    const finish = (error) => {
      if (done) return;
      done = true;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(listener);
      if (error) reject(error);
      else resolve();
    };

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab?.status === "complete") finish();
    }).catch(() => {});
  });
}

async function ensureContentScript(tabId) {
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { type: "PING_TT_DOWNLOADER" });
    if (pong?.ok) return;
  } catch {}

  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  await sleep(300);
}

function waitForDownload(downloadId, timeoutMs = 180000) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      downloadWaiters.delete(downloadId);
      resolve({ ok: false, state: "timeout" });
    }, timeoutMs);

    downloadWaiters.set(downloadId, (result) => {
      clearTimeout(timeout);
      resolve(result);
    });
  });
}

async function closeTabSafe(tabId) {
  if (!tabId) return;
  try { await chrome.tabs.remove(tabId); } catch {}
}

async function revokeBlob(tabId, blobUrl) {
  if (!tabId || !blobUrl) return;
  try {
    await chrome.tabs.sendMessage(tabId, { type: "REVOKE_VIDEO_BLOB", blobUrl });
  } catch {}
}

async function setBatchState(extra = {}) {
  if (!runningBatch) return;
  Object.assign(runningBatch.state, extra, { updatedAt: Date.now() });
  await chrome.storage.local.set({ tiktokBatchState: runningBatch.state });
}

async function prepareInWorkerTab(tabId, item, strict) {
  return chrome.tabs.sendMessage(tabId, {
    type: "PREPARE_TIKTOK_WORKER",
    item,
    strict
  });
}

async function processOne(item, batch) {
  let tabId = null;
  let prepared = null;

  try {
    if (!item?.pageUrl || !/tiktok\.com\//i.test(item.pageUrl)) {
      throw new Error("El video no tiene una URL válida de TikTok.");
    }

    const tab = await chrome.tabs.create({ url: item.pageUrl, active: false });
    tabId = tab.id;
    await waitForTabComplete(tabId);
    await ensureContentScript(tabId);
    await sleep(650);

    prepared = await prepareInWorkerTab(tabId, item, true);
    if (!prepared?.ok) {
      await sleep(1000);
      prepared = await prepareInWorkerTab(tabId, item, false);
    }
    if (!prepared?.ok) throw new Error(prepared?.error || "No se pudo obtener el MP4.");

    const priorId = batch.fingerprints.get(prepared.fingerprint);
    if (priorId && String(priorId) !== String(item.id)) {
      await revokeBlob(tabId, prepared.blobUrl);
      throw new Error(`Duplicado detectado: TikTok devolvió el mismo archivo que para ${priorId}.`);
    }
    batch.fingerprints.set(prepared.fingerprint, item.id || item.pageUrl);

    const started = await downloadFile(prepared.blobUrl, prepared.filename);
    if (!started.ok) {
      await revokeBlob(tabId, prepared.blobUrl);
      throw new Error(started.error || "Chrome no pudo iniciar la descarga.");
    }

    sessions.set(started.downloadId, {
      tabId,
      blobUrl: prepared.blobUrl,
      batchId: batch.id,
      createdAt: Date.now()
    });

    const terminal = await waitForDownload(started.downloadId);
    if (!terminal.ok) {
      throw new Error(terminal.state === "interrupted" ? "La descarga fue interrumpida." : "La descarga agotó el tiempo de espera.");
    }

    return { ok: true, id: item.id, bytes: prepared.bytes };
  } catch (error) {
    if (prepared?.blobUrl) await revokeBlob(tabId, prepared.blobUrl);
    await closeTabSafe(tabId);
    return { ok: false, id: item?.id || null, error: error?.message || String(error) };
  }
}

async function runBatch(items) {
  const id = `batch-${Date.now()}`;
  const batch = {
    id,
    fingerprints: new Map(),
    state: {
      id,
      status: "running",
      total: items.length,
      completed: 0,
      success: 0,
      failed: 0,
      lastError: "",
      startedAt: Date.now(),
      updatedAt: Date.now()
    }
  };
  runningBatch = batch;
  await chrome.storage.local.set({ tiktokBatchState: batch.state });

  let next = 0;
  const concurrency = Math.min(5, items.length);

  const worker = async () => {
    while (true) {
      const index = next++;
      if (index >= items.length) return;
      const item = items[index];
      const result = await processOne(item, batch);

      batch.state.completed += 1;
      if (result.ok) batch.state.success += 1;
      else {
        batch.state.failed += 1;
        batch.state.lastError = result.error || "Error desconocido";
      }
      await setBatchState();
    }
  };

  await Promise.all(Array.from({ length: concurrency }, () => worker()));
  batch.state.status = "complete";
  batch.state.finishedAt = Date.now();
  await setBatchState();
  runningBatch = null;
}

chrome.downloads.onChanged.addListener((delta) => {
  const terminalState = delta.state?.current;
  if (terminalState !== "complete" && terminalState !== "interrupted") return;

  const session = sessions.get(delta.id);
  if (session) {
    sessions.delete(delta.id);
    revokeBlob(session.tabId, session.blobUrl).finally(() => closeTabSafe(session.tabId));
  }

  const waiter = downloadWaiters.get(delta.id);
  if (waiter) {
    downloadWaiters.delete(delta.id);
    waiter({ ok: terminalState === "complete", state: terminalState });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "START_BATCH_DOWNLOAD") {
    (async () => {
      if (runningBatch?.state?.status === "running") {
        sendResponse({ ok: false, error: "Ya hay una descarga por lote en ejecución." });
        return;
      }

      const items = Array.isArray(message.items) ? message.items.filter(Boolean) : [];
      if (!items.length) {
        sendResponse({ ok: false, error: "No hay videos para descargar." });
        return;
      }

      sendResponse({ ok: true, total: items.length });
      runBatch(items).catch(async (error) => {
        if (runningBatch) {
          runningBatch.state.status = "complete";
          runningBatch.state.lastError = error?.message || String(error);
          runningBatch.state.failed = Math.max(runningBatch.state.failed, 1);
          await setBatchState();
          runningBatch = null;
        }
      });
    })();
    return true;
  }
});
